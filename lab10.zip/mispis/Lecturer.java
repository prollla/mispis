public class Lecturer extends ResearchAssociate {

    public void readLecture(){

    }

    public void openAudience(){

    }

    public void closeAudience(){

    }

}