public class Faculty {

	public Faculty(Employee dean, String name) {
		this.dean = dean;
		this.name = name;
	}

	public Employee dean;
	public String name;

	public void holdEvent(){

	}
	public void hireTeachers(){

	}
	public void dismissTeacher(){

	}
	public void makeInquiry(){

	}

}