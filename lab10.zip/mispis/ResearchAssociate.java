public class ResearchAssociate extends Employee {

	public String fieldOfStudy;

}