public class Participation {

	public int hours;

}