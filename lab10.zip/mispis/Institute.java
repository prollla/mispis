public class Institute {

	public Institute(String name, String address) {
		this.name = name;
		this.address = address;
	}

	public String name;
	public String address;

	public void open(){

	}
	public void close(){

	}

	public Integer showRating(){
		Integer rating = 100;
		return rating;
	}

}