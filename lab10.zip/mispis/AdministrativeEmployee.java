public class AdministrativeEmployee extends Employee {

}